from .sinter import *

__doc__ = sinter.__doc__
if hasattr(sinter, "__all__"):
    __all__ = sinter.__all__